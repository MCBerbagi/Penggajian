<body>
<form method="post" action="addlembur.php">
<table width="766">
  <tr>
    <td colspan="3"><div align="center">DATA LEMBUR</div></td>
  </tr>
  <tr>
    <td>Id_Lembur</td>
    <td>:</td>
    <td><input class="field" type="text" name="id_lembur" /></td>
  </tr>
  <tr>
    <td>TANGGAL</td>
    <td>:</td>
    <td><input type="hidden" name="hiddenField" id="hiddenField"></td>
      </tr>
  <tr>
    <td width="241">NIP</td>
    <td width="18">:</td>
    <td width="485"><input class="field" type="text" name="nip" /></td>
  </tr>
  <tr>
    <td>NAMA</td>
    <td>:</td>
    <td><input class="field" type="text" name="nama" /></td>
  </tr>
  <tr>
    <td>ID_DEPARTEMEN</td>
    <td>:</td>
    <td><input class="field" type="text" name="id_departemen" /></td>
  </tr>
  <tr>
    <td>DEPARTEMEN</td>
    <td>:</td>
    <td><input class="field" type="text" name="departemen" /></td>
  </tr>
  <tr>
    <td>JAM MULAI</td>
    <td>:</td>
    <td><input class="field" type="text" name="jam_mulai" /></td>
  </tr>
  <tr>
    <td>JAM SELESAI</td>
    <td>:</td>
    <td><input class="field" type="text" name="jam_selesai" /></td>
  </tr>
    <tr>
    <td colspan="2" align="right">
    <input class="button" type="submit" value="Simpan" />
    <input class="button" type="reset" value="Batal" />
    </td>
  </tr>
</table>
</form>
</body>
</html>
