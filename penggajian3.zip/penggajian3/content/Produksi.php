<body>
<form method="post" action="addproduksi.php">
<table width="766">
  <tr>
    <td colspan="3"><div align="center">Produksi</div></td>
  </tr>
  <tr>
    <td>ID_JENIS</td>
    <td>:</td>
    <td><input class="field" type="text" name="id_jenis" /></td>
  </tr>
  <tr>
    <td width="241">NAMA</td>
    <td width="18">:</td>
    <td width="485"><input class="field" type="text" name="nama_jenis" /></td>
  </tr>
  <tr>
    <td>HARGA PER/KG</td>
    <td>:Rp</td>
    <td><input class="field" type="text" name="harga" /></td>
  </tr>
  <tr>
    <td colspan="2" align="right"><label>
      <input type="submit" name="button" id="button" value="Submit">
    </label></td>
  </tr>
</table>
</form>
</body>