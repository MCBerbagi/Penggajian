
<body>
<table width="1073" border="1">
  <tr>
    <td width="624">&nbsp;</td>
    <td width="16">&nbsp;</td>
    <td width="89">&nbsp;</td>
    <td width="16">&nbsp;</td>
    <td width="1">&nbsp;</td>
    <td width="9">&nbsp;</td>
    <td width="246">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">A. NOMOR INDUK</span></td>
    <td>:</td>
    <td colspan="5"></td>
  </tr>
  <tr>
    <td><span class="style4">B. NAMA PEMOTONG PAJAK</span></td>
    <td>:</td>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">C .NPWP PEMOTONG PAJAK</span></td>
    <td>:</td>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">D. ALAMAT PEMOTONG PAJAK</span></td>
    <td>:</td>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr>
    <td>E. <span class="style4">NAMA PEGAWAI ATAU PENERIMA PENSIUN/THT</span></td>
    <td>:</td>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">F. NPWP PEGAWAI ATAU PENERIMA PENSIUN/THT</span></td>
    <td>:</td>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">G. ALAMAT PEGAWAI ATAU PENERIMA PENSIUN/THT</span></td>
    <td>:</td>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">H. JABATAN</span></td>
    <td>:</td>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">I. STATUS DAN JENIS KELAMIN</span></td>
    <td>:</td>
    <td colspan="5">
    <input type="radio" name="JK" id="radio5" value="radio5" />
    KAWIN 
    <input type="radio" name="JK" id="radio6" value="radio6" />
    TIDAK KAWIN
    <input type="radio" name="JK" id="radio7" value="radio7" />
    LAKI-LAKI 
    <input type="radio" name="JK" id="radio8" value="radio8" />
    PEREMPUAN 
    </td>
  </tr>
  <tr>
    <td height="30"><span class="style4">J. JUMLAH TANGGUNGAN KELUARGA UNTUK PTKP</span></td>
    <td>:</td>
    <td colspan="5">K/ 
      <input type="text" name="tanggungan" id="tanggungan" />
      TK/
      <input type="text" name="tanggungan" id="tanggungan" />
      </form>    </td>
  </tr>
  <tr>
    <td><span class="style4">K. MASA PEROLEHAN PENGHASILAN</span></td>
    <td>:</td>
    <td colspan="5">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">L. RINCIAN PENGHASILAN DAN PERHITUNGAN PPh PASAL 21 SEBAGAI BERIKUT</span></td>
    <td>:</td>
    <td colspan="5"></td>
  </tr>
  <tr>
    <td colspan="7"><ul class="style4">
      <li><strong>PENGHASILAN BRUTO</strong></li>
    </ul></td>
  </tr>
  <tr>
    <td><span class="style4">1. GAJI/PENSIUN/THT</span></td>
    <td>1</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">2. TUNJANGAN PPh</span></td>
    <td>2</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">3. TUNJANGAN LAINNYA, UANG LEMBUR, DSB</span></td>
    <td>3</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">4. HONORARIUM DAN IMBALAN LAIN SEJENIS</span></td>
    <td>4</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">5. PREMI ASURANSI YANG DIBAYAR PEMBERI KERJA</span></td>
    <td>5</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">6. PENERIMA DALAM BENTUK NATURA DAN KENIKMATAN LAINNYA YANG DIKENAKAN PEMOTONGAN PPh PASAL 21</span></td>
    <td>6</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">7. JUMLAH ( 1 S.D.6 )</span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>7</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">8. TANTIEM, BONUS, GRATIFIKASI, JASA PRODUKSI, DAN THR</span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>8</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">9. JUMLAH PENGHASILAN BRUTO (7+8)</span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>9</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="7"><ul class="style4">
      <li><strong>PENGURANGAN</strong></li>
    </ul></td>
  </tr>
  <tr>
    <td><span class="style4">10. BIAYA JABATAN/PENSIUN ATAS PENGHASILAN PADA ANGKA 7</span></td>
    <td>10</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">11. BIAYA JABATAN/PENSIUN ATAS PENGHASILAN PADA ANGKA 8</span></td>
    <td>11</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">12. IURAN PENSIUN,IURAN THT</span></td>
    <td>12</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td  colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style4">13. JUMLAH PENGURANGAN (10+11+12)</span></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>13</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="7"><ul class="style4">
      <li><strong>PERHITUNGAN PPh PASAL 21</strong></li>
    </ul></td>
  </tr>
  <tr>
    <td colspan="3"><span class="style4">14. JUMLAH PENGHASILAN NETO (9-13)</span></td>
    <td>14</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><span class="style4">15. PENGHASILAN NETO MASA SEBELUMNYA</span></td>
    <td>15</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><span class="style4">16. JUMLAH PENGHASILAN NETO UNTUK PERHITUNGAN PPh PASAL 21 (SETAHUN/DISETAHUNKAN)</span></td>
    <td>16</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><span class="style4">17. PENGHASILAN TIDAK KENA PAJAK (PTKP)</span></td>
    <td>17</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><span class="style4">18. PENGHASILAN KENA PAJAK SETAHUN/DISETAHUNKAN (16-17)</span></td>
    <td>18</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><span class="style4">19. PPh PASAL 21 ATAS PENGHASILAN KENA PAJAK SETAHUN/DISETAHUNKAN</span></td>
    <td>19</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><span class="style4">20. PPh PASAL 21 YANG TELAH DIPOTONG MASA SEBELUMNYA</span></td>
    <td>20</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><span class="style4">21. PPh PASAL 21 TERUTANG</span></td>
    <td>21</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><span class="style4">22. PPh PASAL 21 DAN PPh PASAL 26 YANG TELAH DIPOTONG DAN DILUNASI</span></td>
    <td>22</td>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="7"><span class="style4">23. JUMLAH PPh PASAL 21</span></td>
  </tr>
  <tr>
    <td colspan="3">
      <input type="radio" name="dipotong" id="radio" value="radio" />
      <span class="style4">YANG KURANG DIPOTONG (21-22)
          <input type="radio" name="dipotong" id="radio2" value="radio2" />
     YANG LEBIH DIPOTONG (22-21)</td>
    <td>23</td>
    <td colspan="3">&nbsp;</td>
  </tr>
 <tr>
    <td colspan="7"><span class="style4">24. JUMLAH TERSEBUT PADA ANGKA 23 TELAH</span></td>
  </tr>
  <tr>
    <td colspan="3">
        <input type="radio" name="pembayaran" id="radio3" value="radio3" />
      <span class="style4">DIPOTONG DARI PEMBAYARAN GAJI BULAN..............................TAHUN............</span>..
         <input type="radio" name="perhitungan" id="radio4" value="radio4" />
        DIPERHITUNGKAN DENGAN PPh PASAL 21 SEBULAN................TAHUN..............
    </td>
     <td>24</td>
    <td colspan="3">&nbsp;</td>
  </tr>
     <td colspan="7">
        <input type="radio" name="pemotong" id="radio3" value="radio3" />
      <span class="style4">PEMOTONG PAJAK      </span>
          <input type="radio" name="kuasa" id="radio4" value="radio4" />
        </label>
        KUASA
      </form>      
      <form id="form3" name="form3" method="post" action="">
      <label>TANDA TANGAN</label>
      </form>
      <form action="" method="post" name="form4" class="style4" id="form4">
        <label>NAMATERANG</label>
      </form>      </td>
  </tr>
  <tr>
    <td colspan="7"><form action="" method="post" name="form5" class="style4" id="form5">
      <p>.............................TGL................</p>
    </form>    
    <td width="20">&nbsp;</td>
  </tr>
</table>
</body>
</html>
