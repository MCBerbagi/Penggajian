<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {font-size: 13px}
-->
</style>
</head>

<body>
<table width="918" border="1">
  <tr>
    <td width="14">&nbsp;</td>
    <td width="175">&nbsp;</td>
    <td width="23">&nbsp;</td>
    <td width="218">&nbsp;</td>
    <td width="194">&nbsp;</td>
    <td width="254">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><span class="style1">A.</span></td>
    <td><span class="style1">NPWP PEMOTONG PAJAK</span></td>
    <td><span class="style1">:</span></td>
    <td colspan="2"><span class="style1"></span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1">B. </span></td>
    <td><span class="style1">NAMA PEMOTONG PAJAK</span></td>
    <td><span class="style1">:</span></td>
    <td colspan="2"><span class="style1"></span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1">C. </span></td>
    <td><span class="style1">ALAMAT PEMOTONG PAJAK</span></td>
    <td><span class="style1">:</span></td>
    <td colspan="2"><span class="style1"></span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1"></span> </td>
    <td><span class="style1">KOTA/KODE POS</span></td>
    <td><span class="style1">:</span></td>
    <td colspan="2"><span class="style1"></span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1"></span></td>
    <td><span class="style1">TELEPON/FAX</span></td>
    <td><span class="style1">:</span></td>
    <td colspan="2"><span class="style1"></span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1">D</span></td>
    <td><span class="style1">JENIS USAHA</span></td>
    <td><span class="style1">:</span></td>
    <td colspan="2"><span class="style1"></span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1">E</span></td>
    <td><span class="style1">NAMA PIMPINAN</span></td>
    <td><span class="style1">:</span></td>
    <td colspan="2"><span class="style1"></span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td colspan="1"><span class="style1">F</span></td>
    <td colspan="6"><span class="style1">DALAM TAHUN TAKWIM YANG BERSANGKUTAN TELAH MELAKUKAN PEMOTONGAN DAN PENYETORAN PPh PASAL 21 DAN PPh PASAL 26 SEBAGAI BERIKUT</span></td>
  </tr>
  <tr>
    <td colspan="3"><span class="style1">GOLONGAN PEGAWAI</span></td>
    <td><p class="style1">JUMLAH PENERIMA PENGHASILAN</p>    </td>
    <td><span class="style1">JUMLAH PENGHASILAN BRUTO (Rp)</span></td>
    <td><span class="style1">PPh PASAL 21/26 TERUTANG (Rp)</span></td>
  </tr>
  <tr>
    <td colspan="3"><div align="center"><span class="style1">(1)</span></div></td>
    <td><div align="center"><span class="style1">(2)</span></div></td>
    <td><div align="center"><span class="style1">(3)</span></div></td>
    <td><div align="center"><span class="style1">(4)</span></div></td>
  </tr>
  <tr>
    <td><span class="style1">1</span></td>
    <td colspan="2"><span class="style1">PEGAWAI TETAP DENGAN PENERIMA PENSIUN/TUNJANGAN HARI TUA (DIISI DARI FORMULIR 1721-A</span></td>
    <td><span class="style1"></span></td>
    <td><span class="style1"></span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1">2</span></td>
    <td colspan="2"><span class="style1">PEGAWAI TIDAK TETAP/PENERIMA HONORARIUM DAN PENGHASILAN LAINNYA/PENERIMA PENGHASILAN YANG DIKENAKAN PPh PASAL 21 BERSIFAT FINAL (DIISI DARI FORMULIR 1721-B)</span></td>
    <td><span class="style1"></span></td>
    <td><span class="style1"></span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1">3</span></td>
    <td colspan="2"><span class="style1">JUMLAH (1+2)</span></td>
    <td><span class="style1"></span></td>
    <td><span class="style1"></span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1">4</span></td>
    <td colspan="4"><span class="style1">PPh PASAL 21/PASAL 26 YANG TELAH DISETOR</span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1">5</span></td>
    <td colspan="4"><span class="style1">STP PPh 21/PASAL 26 (HANYA POKOK PAJAK)</span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1">6</span></td>
    <td colspan="4"><span class="style1">JUMLAH (4+5)</span></td>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1">7</span></td>
    <td colspan="4"><form action="" method="post" name="form1" class="style1" id="form1">
      a
      <label>
        <input type="radio" name="radio" id="radio" value="radio" />
        </label>
      PPh PASAL 21/PASAL26 YANG KURANG DISETOR (ANGKA 3 KOLOM 4 - ANGKA 6)
    </form>    </td>
    <td><span class="style1"></span></td></tr>
    <tr>
    <td><span class="style1"></span></td>
    <td colspan="4"><span class="style1">b      
      <input type="radio" name="radio2" id="radio2" value="radio2" />
      PPh PASAL 21/PASAL 26 YANG LEBIH DISETOR (ANGKA 6 - ANGKA 3 KOLOM 4)
     </span>
    <td><span class="style1"></span></td>
  </tr>
  <tr>
    <td><span class="style1"></span></td>
    <td colspan="7"><span class="style1">JUMLAH PADA ANGKA 7a TELAH DILUNASI PADA TANGGAL </span></td>
  </tr>
  <tr>
    <td><span class="style1">G</span></td>
    <td colspan="5"><p class="style1">PEMOHONONAN</p>
    <p class="style1">PPh PAASAL 21 YANG LEBIH DISETOR PADA ANGKA 7b MOHON DIPERHITUNGKAN DENGAN PEMBAYARAN PPh PASAL 21 UNTUK BULAN </p></td>
  </tr>
  <tr>
    <td><span class="style1">H</span></td>
    <td colspan="7"><p class="style1">LAMPIRAN</p>
    <p class="style1">SELAIN LAMPIRAN (1721-A, 1721-A1 ATAU 1721-A2, 1721-B DAN 1721-C BERSAMA INI KAMI LAMPIRAN PULA :</p></td>
  </tr>
  <tr>
    <td><span class="style1"></span></td>
    <td colspan="3"><form action="" method="post" name="form3" class="style1" id="form3">
      <label>
        <input type="radio" name="radio3" id="radio3" value="radio3" />
        </label>
      SURAT SETORAN PAJAK
    </form>    </td>
    <td colspan="3"><form action="" method="post" name="form6" class="style1" id="form6">
      <label>
        <input type="radio" name="radio6" id="radio6" value="radio6" />
        </label>
    PEMBERITAHUAN PEMBETULAN NAMA/DANA/ALAMAT
    </form>    </td>
  </tr>
  <tr>
    <td><span class="style1"></span></td>
    <td colspan="3"><form action="" method="post" name="form4" class="style1" id="form4">
      <label>
        <input type="radio" name="radio4" id="radio4" value="radio4" />
        </label>
    SURAT KUASA KHUSUS
    </form>    </td>
    <td colspan="2"><form action="" method="post" name="form7" class="style1" id="form7">
      <label>
        <input type="radio" name="radio7" id="radio7" value="radio7" />
        </label>
    LAINNYA
    </form>    </td>
  </tr>
  <tr>
    <td><span class="style1"></span></td>
    <td colspan="3"><form action="" method="post" name="form5" class="style1" id="form5">
      <label>
        <input type="radio" name="radio5" id="radio5" value="radio5" />
        </label>
    LAPORAN KEUANGAN KERJASAMA OPERASI DALAM HAL PEMOTONG PAJAK
    </form>    </td>
    <td colspan="3"><span class="style1"></span></td>
  </tr>
    <tr>
  <td><span class="style1"></span></td>
    <td colspan="4"><span class="style1"></span></td>
    <td><span class="style1"></span></td>
    </tr>
    <tr>
  <td><span class="style1"></span></td>
    <td colspan="2"><form action="" method="post" name="form8" class="style1" id="form8">
      <label>
        <input type="radio" name="radio8" id="radio8" value="radio8" />
        </label>
    PEMOTONG PAJAK
    </form>    </td>
    <td colspan="3"><span class="style1">TANDA TANGAN</span></td>
    </tr>
    <tr>
  <td><span class="style1"></span></td>
    <td colspan="2"><form action="" method="post" name="form9" class="style1" id="form9">
      <label>
        <input type="radio" name="radio9" id="radio9" value="radio9" />
        </label>
    KUASA
    </form>    </td>
    <td colspan="3"><span class="style1">NAMA TERANG</span></td>
    </tr>
</table>
</body>
</html>
