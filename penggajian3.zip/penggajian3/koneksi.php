<?
$koneksi=mysql_connect("localhost","cintaind_root","eW!NGdOszCA~");
$selectdb= mysql_select_db('cintaind_gaji') or die (' maaf database tidak ditemukan');
?>